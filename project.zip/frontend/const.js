export default {
	baseUrl: 'https://10.133.140.131:7053',
	uploadUrl: '/api/files/upload',
}
